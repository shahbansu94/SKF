﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace SKF.Admin
{
    public partial class Profile : System.Web.UI.Page
    {
        Connect cls = new Connect();
        string sqlstmt = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
               
                HttpCookie reqCookies = Request.Cookies["userInfo"];
                if (reqCookies != null)
                {
                    lblHeaderUser.Text = reqCookies["UserName"].ToString();
                }
                else
                {
                    lblHeaderUser.Text = "Student";
                }
                GetData();
                GetParentData();
                GetClasses();
                GetProgress();
            }
        }

        public void GetData()
        {
            sqlstmt = "";
            sqlstmt = "SELECT * FROM student_master WHERE stu_email = '"+ lblHeaderUser.Text +"' ";
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                lblUserName.Text = ds.Tables[0].Rows[0]["stu_fname"].ToString();
                lblUserPhone.Text = ds.Tables[0].Rows[0]["stu_phone"].ToString();
                lblUserDOB.Text = ds.Tables[0].Rows[0]["stu_dob"].ToString();
            }
        }

        public void GetParentData()
        {
            sqlstmt = "";
            sqlstmt = "SELECT parents_master.parent_id,parents_master.parent_stu_id,parents_master.parent_relation_id,parents_master.parent_name,parents_master.parent_email,parents_master.parent_phone,student_master.stu_id,student_master.stu_fname,student_master.stu_mname,student_master.stu_lname,student_master.stu_email,student_master.stu_phone,student_master.stu_dob,student_master.stu_join_date,student_master.stu_is_active,student_master.stu_available_credit FROM parents_master INNER JOIN student_master ON parents_master.parent_stu_id = student_master.stu_id WHERE student_master.stu_email = '" + lblHeaderUser.Text + "' ";
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                lblparent_name.Text = ds.Tables[0].Rows[0]["parent_name"].ToString();
                lblparent_email.Text = ds.Tables[0].Rows[0]["parent_email"].ToString();
                lblparent_phone.Text = ds.Tables[0].Rows[0]["parent_phone"].ToString();
            }
        }

        public void GetClasses()
        {
            sqlstmt = "";
            sqlstmt = "SELECT enroll_master.enroll_id, enroll_master.enroll_student_id, enroll_master.enroll_class_id, enroll_master.enroll_status, enroll_master.enroll_date, class_master.class_id, class_master.class_level_id, class_master.class_days, class_master.class_level_time, class_master.class_ins_id, class_level_master.class_level_id, class_level_master.class_level, class_level_master.class_level_desc, class_level_master.class_start_date, class_level_master.class_end_date, class_level_master.class_start_time, class_level_master.class_end_time FROM enroll_master INNER JOIN student_master ON enroll_master.enroll_student_id = student_master.stu_id INNER JOIN class_master ON enroll_master.enroll_class_id = class_master.class_id INNER JOIN class_level_master ON class_master.class_level_id = class_level_master.class_level_id WHERE student_master.stu_email = '" + lblHeaderUser.Text + "' ";
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                class_level.Text = ds.Tables[0].Rows[0]["class_level"].ToString();
                class_start_date.Text = ds.Tables[0].Rows[0]["class_start_date"].ToString();
                class_end_date.Text = ds.Tables[0].Rows[0]["class_end_date"].ToString();
                class_start_time.Text = ds.Tables[0].Rows[0]["class_start_time"].ToString();
                class_end_time.Text = ds.Tables[0].Rows[0]["class_end_time"].ToString();
            }
        }

        public void GetProgress()
        {
            sqlstmt = "";
            sqlstmt = "SELECT progress_master.progress_id, progress_master.progress_stu_id, progress_master.progress_rank_id, progress_master.progress_activity_id, progress_master.progress_date, progress_master.progress_status, activity_master.activity_id, activity_master.activity_class_level_id, activity_master.activity_name, activity_master.activity_description, activity_master.activity_startdate, activity_master.activity_enddate, student_master.stu_id, student_master.stu_fname, student_master.stu_mname, student_master.stu_lname, student_master.stu_email, student_master.stu_phone, student_master.stu_dob, student_master.stu_join_date, student_master.stu_is_active, student_master.stu_available_credit, class_level_master.class_level_id, class_level_master.class_level, class_level_master.class_level_desc, class_level_master.class_start_date, class_level_master.class_end_date, class_level_master.class_start_time, class_level_master.class_end_time FROM progress_master INNER JOIN activity_master ON progress_master.progress_activity_id = activity_master.activity_id INNER JOIN student_master ON progress_master.progress_stu_id = student_master.stu_id INNER JOIN class_level_master ON activity_master.activity_class_level_id = class_level_master.class_level_id WHERE student_master.stu_email = '" + lblHeaderUser.Text + "' ";
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                activity_name.Text = ds.Tables[0].Rows[0]["activity_name"].ToString();
                progress_date.Text = ds.Tables[0].Rows[0]["progress_date"].ToString();
            }
        }
    }
}
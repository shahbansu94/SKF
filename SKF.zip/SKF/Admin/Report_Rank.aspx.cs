﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SKF.Admin
{
    public partial class Report_Rank : System.Web.UI.Page
    {
        Connect cls = new Connect();
        string sqlstmt = "";
        string QryParam = " where rh.rank_type_id is null ";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindData(QryParam);
                BindRankType();
               // BindRelation();
            }

        }

        public void BindRankType()
        {
            //Response.Redirect("Report_Rank.aspx");
            sqlstmt = "";
            sqlstmt = "Select * from rank_type_master";
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                listRankType.DataSource = ds.Tables[0];
                listRankType.DataTextField = "rank_type_belt";
                listRankType.DataValueField = "rank_type_id";
                listRankType.DataBind();
            }
            else
            {
                listRankType.DataSource = System.DBNull.Value.ToString();
                listRankType.DataBind();
            }
           
        }

        public void BindData(string QryParam)
        {
            sqlstmt = "";
            sqlstmt = "Select stu_email,rank_type_belt,rank_date from rank_history rh left join rank_type_master rt on rh.rank_type_id=rt.rank_type_id left join student_master s on s.stu_id=rh.rank_stu_id"+ QryParam + "";
            System.Data.DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
               
                Lst_RankRpt.DataSource = ds.Tables[0];
                Lst_RankRpt.DataBind();
            }
            else
            {
                Lst_RankRpt.DataSource = null;
            }
            
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            QryParam = "";
             QryParam = " where";
            string RankList = "";
            
            string StartDate = TxtStartDate.Value.Trim();
            string EndDate = txtEndDate.Value.Trim(); 
            int i = 0;
            foreach (ListItem li in listRankType.Items)
            {
               
               if(li.Selected)
                { 
                if(i>=1)
                    {
                        RankList = RankList + ",";
                        
                    }
                RankList = RankList + li.Value;
                    i++;
                }
            }
            if (RankList != "")
            {
                QryParam =QryParam + " rh.rank_type_id in ("+ RankList +") ";
            }
            if(StartDate != "")
            {
                if(QryParam != " where")
                {
                    QryParam =QryParam + "and rank_date >= '"+ StartDate + "'";
                }
                else
                {
                    QryParam = QryParam + "  rank_date >= '" + StartDate + "'";
                }
            }
            if (EndDate != "")
            {
                if (QryParam != " where")
                {
                    QryParam = QryParam + "and rank_date <= '" + EndDate + "'";
                }
                else
                {
                    QryParam = QryParam + "  rank_date <= '" + EndDate + "'";
                }
            }
            BindData(QryParam);
            //Response.Redirect("Report_Rank.aspx");
            //CrudOP();
        }

        private void ShowMessageBox()
        {
            string sJavaScript = "<script language=javascript>\n";
            sJavaScript += "agree = confirm('Record Deleted...'); \n";
            sJavaScript += "if(agree)\n";
            sJavaScript += "window.location = \"Add_Parents.aspx\";\n";
            sJavaScript += "</script>";
            Response.Write(sJavaScript);
        }
    }
}
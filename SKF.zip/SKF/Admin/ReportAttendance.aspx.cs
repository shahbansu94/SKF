﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace SKF.Admin
{
    public partial class ReportAttendance : System.Web.UI.Page
    {
        Connect cls = new Connect();
        string sqlstmt = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindClassLevel();                               
            }
        }

      
        public void BindData()
        {
            sqlstmt = "";
            sqlstmt = "SELECT student_master.stu_id,student_master.stu_fname,student_master.stu_lname,class_level_master.class_level,attendance_master.attendance_date FROM student_master INNER JOIN enroll_master ON enroll_master.enroll_student_id = student_master.stu_id INNER JOIN class_master ON enroll_master.enroll_class_id = class_master.class_id INNER JOIN class_level_master ON class_master.class_level_id = class_level_master.class_level_id INNER JOIN attendance_master ON attendance_master.attendance_class_id = class_master.class_id WHERE enroll_master.enroll_student_id =" + DropClassLevel.SelectedValue;

            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                Lst_Fees_Report.Visible = true;
                Lst_Fees_Report.DataSource = ds.Tables[0];
                Lst_Fees_Report.DataBind();
            }
            else
            {
                Lst_Fees_Report.DataSource = null;
                Lst_Fees_Report.Visible = false;
            }
        }

        
        public void BindClassLevel()
        {
            sqlstmt = "";
            sqlstmt = "Select * from class_level_master";
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                DropClassLevel.DataSource = ds.Tables[0];
                DropClassLevel.DataTextField = "class_level";
                DropClassLevel.DataValueField = "class_level_id";
                DropClassLevel.DataBind();
            }
            else
            {
                DropClassLevel.DataSource = System.DBNull.Value.ToString();
                DropClassLevel.DataBind();
            }
            DropClassLevel.Items.Insert(0, "--Select--");
        }

        public void BindData1()
        {
            string startdate = TxtStartDate.Value.Trim();
            string enddate = txtEndDate.Value.Trim();
            sqlstmt = "";
                      
              sqlstmt = "SELECT student_master.stu_id,student_master.stu_fname,student_master.stu_lname,class_level_master.class_level,attendance_master.attendance_date FROM student_master INNER JOIN enroll_master ON enroll_master.enroll_student_id = student_master.stu_id INNER JOIN class_master ON enroll_master.enroll_class_id = class_master.class_id INNER JOIN class_level_master ON class_master.class_level_id = class_level_master.class_level_id INNER JOIN attendance_master ON attendance_master.attendance_class_id = class_master.class_id WHERE attendance_date BETWEEN '" + startdate + "' AND '" + enddate + "'";

                DataSet ds = cls.Select(sqlstmt);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    Lst_Fees_Report.Visible = true;
                    Lst_Fees_Report.DataSource = ds.Tables[0];
                    Lst_Fees_Report.DataBind();
                }
                else
                {
                    Lst_Fees_Report.DataSource = null;
                    Lst_Fees_Report.Visible = false;
                }
            }

        protected void DropClassLevel_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindData();
        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            BindData1();
        }

    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace SKF.Admin
{
    public partial class Add_Enroll_Student : System.Web.UI.Page
    {
        Connect cls = new Connect();
        string sqlstmt = "";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindClassLevel();
                BindStudent();
                var unique_id = Request.QueryString["id"];
                if (unique_id != null)
                {
                    GetData();
                }
            }
        }

        public void BindClassLevel()
        {
            sqlstmt = "";
            sqlstmt = "SELECT * FROM class_master INNER JOIN class_level_master ON class_master.class_level_id = class_level_master.class_level_id";
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                ds.Tables[0].Columns.Add("classAndDay", typeof(string), "class_level + ' - ' + class_days");
                DropClassLevel.DataSource = ds.Tables[0];
                DropClassLevel.DataTextField = "classAndDay";
                DropClassLevel.DataValueField = "class_id";
                DropClassLevel.DataBind();
            }
            else
            {
                DropClassLevel.DataSource = System.DBNull.Value.ToString();
                DropClassLevel.DataBind();
            }
            DropClassLevel.Items.Insert(0, "--Select--");
        }

        public void BindTime()
        {
            sqlstmt = "";
            sqlstmt = "SELECT * FROM class_master WHERE class_master.class_id = " + DropClassLevel.SelectedValue;
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                txtclasstime.Text = ds.Tables[0].Rows[0]["class_level_time"].ToString();                
            }
        }

        public void BindStudent()
        {
            sqlstmt = "";
            sqlstmt = "Select * from student_master";
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                DropStuEmail.DataSource = ds.Tables[0];
                DropStuEmail.DataTextField = "stu_email";
                DropStuEmail.DataValueField = "stu_id";
                DropStuEmail.DataBind();
            }
            else
            {
                DropStuEmail.DataSource = System.DBNull.Value.ToString();
                DropStuEmail.DataBind();
            }
            DropStuEmail.Items.Insert(0, "--Select--");
        }
        public void GetData()
        {
            var unique_id = Request.QueryString["id"];
            if (unique_id != null)
            {
                sqlstmt = "";
                sqlstmt = "SELECT * FROM enroll_master INNER JOIN class_master ON enroll_master.enroll_class_id = class_master.class_id INNER JOIN class_level_master ON class_master.class_level_id = class_level_master.class_level_id INNER JOIN student_master ON enroll_master.enroll_student_id = student_master.stu_id where enroll_id = " + unique_id.ToString();

                DataSet ds = cls.Select(sqlstmt);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    DropClassLevel.SelectedValue = ds.Tables[0].Rows[0]["class_level_id"].ToString();
                    DropStuEmail.SelectedValue = ds.Tables[0].Rows[0]["stu_id"].ToString();
                    txtclasstime.Text = ds.Tables[0].Rows[0]["class_level_time"].ToString();
                }
            }

        }

        public void CrudOP()
        {
            var unique_id = Request.QueryString["id"];
            if (unique_id == null)
            {
                string cdate = System.DateTime.Now.ToString("yyyy-MM-dd");
                sqlstmt = "";
                sqlstmt = "Insert into enroll_master (enroll_student_id,enroll_class_id,enroll_date,enroll_status) values ('" + DropStuEmail.SelectedValue.Trim() + "','" + DropClassLevel.SelectedValue.Trim() + "','" + cdate.ToString() + "','Enrolled')";
                cls.Insert(sqlstmt);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "EnrollStudents", "alert('Record Inserted..!')", true);
                Response.Redirect("Student_Enroll.aspx");
                //ShowMessageBox("Activities.aspx","Record Inserted..!");    
            }
            else
            {
                string cdate = System.DateTime.Now.ToString("yyyy-MM-dd");
                sqlstmt = "";
                sqlstmt = "Update enroll_master set enroll_student_id = '" + DropStuEmail.SelectedValue.Trim() + "', enroll_class_id = '" + DropClassLevel.SelectedValue.Trim() + "', enroll_date = '" + cdate.ToString() + "' where enroll_id = " + unique_id.ToString();
                cls.Update(sqlstmt);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Activity", "alert('Record Updated..!')", true);
                Response.Redirect("Student_Enroll.aspx");
                //ShowMessageBox("Activities.aspx", "Record Updated..!");
            }
        }
        private void ShowMessageBox(string sURL, string mSG)
        {
            string sJavaScript = "<script language=javascript>\n";
            sJavaScript += "agree = confirm(" + mSG + "); \n";
            sJavaScript += "if(agree)\n";
            sJavaScript += "window.location = \"" + sURL + "\";\n";
            sJavaScript += "</script>";
            Response.Write(sJavaScript);
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            CrudOP();
        }

        protected void DropClassLevel_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindTime();
        }
    }
}
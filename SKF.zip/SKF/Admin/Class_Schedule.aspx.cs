﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SKF.Admin
{
    public partial class Class_Schedule : System.Web.UI.Page
    {
        Connect cls = new Connect();
        string sqlstmt = "";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindData();
            }
        }

        public void BindData()
        {
            sqlstmt = "";
            sqlstmt = "SELECT * FROM class_master INNER JOIN class_level_master ON class_master.class_level_id = class_level_master.class_level_id INNER JOIN instructor_master ON class_master.class_ins_id = instructor_master.inst_id";
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                Lst_Set_ClassTimings.DataSource = ds.Tables[0];
                Lst_Set_ClassTimings.DataBind();
            }
            else
            {
                Lst_Set_ClassTimings.DataSource = null;
            }
        }


        protected void lnkEdit_Click(object sender, EventArgs e)
        {
            LinkButton lnk = (LinkButton)sender;
            string idn = lnk.CommandArgument.ToString();

            Response.Redirect("Add_Class_Schedule.aspx?id=" + idn);
        }

        protected void lnkDelete_Click(object sender, EventArgs e)
        {
            LinkButton lnk = (LinkButton)sender;
            string idn = lnk.CommandArgument.ToString();
            sqlstmt = "";
            sqlstmt = "Delete from class_master where class_id=" + idn.ToString();
            cls.Delete(sqlstmt);
            ShowMessageBox();
        }
        private void ShowMessageBox()
        {
            string sJavaScript = "<script language=javascript>\n";
            sJavaScript += "agree = confirm('Record Deleted...'); \n";
            sJavaScript += "if(agree)\n";
            sJavaScript += "window.location = \"Class_Schedule.aspx\";\n";
            sJavaScript += "</script>";
            Response.Write(sJavaScript);
        }


    }
}
   
﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SKF.Admin
{
    public partial class EnrollStudents : System.Web.UI.Page
    {
        Connect cls = new Connect();
        string sqlstmt = "";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindData();
            }
        }

        public void BindData()
        {
            sqlstmt = "";
            sqlstmt = "SELECT * FROM enroll_master INNER JOIN class_master ON enroll_master.enroll_class_id = class_master.class_id INNER JOIN class_level_master ON class_master.class_level_id = class_level_master.class_level_id INNER JOIN student_master ON enroll_master.enroll_student_id = student_master.stu_id";
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                Lst_EnrollStudents.DataSource = ds.Tables[0];
                Lst_EnrollStudents.DataBind();
            }
            else
            {
                Lst_EnrollStudents.DataSource = null;
            }
        }

        protected void lnkEdit_Click(object sender, EventArgs e)
        {
            LinkButton lnk = (LinkButton)sender;
            string idn = lnk.CommandArgument.ToString();
            Response.Redirect("Add_Enroll_Student.aspx?id=" + idn);
        }

        protected void lnkDelete_Click(object sender, EventArgs e)
        {
            LinkButton lnk = (LinkButton)sender;
            string idn = lnk.CommandArgument.ToString();
            sqlstmt = "";
            //sqlstmt = "Delete from enroll_master where enroll_id = " + idn.ToString();
            sqlstmt = "Update enroll_master set enroll_status = 'Not Enrolled' where enroll_id = " + idn.ToString();
            cls.Delete(sqlstmt);
            ShowMessageBox();
        }
        private void ShowMessageBox()
        {
            string sJavaScript = "<script language=javascript>\n";
            sJavaScript += "agree = confirm('Record Deleted...'); \n";
            sJavaScript += "if(agree)\n";
            sJavaScript += "window.location = \"EnrollStudents.aspx\";\n";
            sJavaScript += "</script>";
            Response.Write(sJavaScript);
        }
    }
}




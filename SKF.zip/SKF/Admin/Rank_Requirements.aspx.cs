﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace SKF.Admin
{
    public partial class Rank_Requirements : System.Web.UI.Page
    {
        Connect cls = new Connect();
        string sqlstmt = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindRankType();
                BindStudents();
                BindData();
            }
        }
        public void BindRankType()
        {
            sqlstmt = "";
            sqlstmt = "Select * from rank_type_master";
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                DropRankType.DataSource = ds.Tables[0];
                DropRankType.DataTextField = "rank_type_belt";
                DropRankType.DataValueField = "rank_type_id";
                DropRankType.DataBind();
            }
            else
            {
                DropRankType.DataSource = System.DBNull.Value.ToString();
                DropRankType.DataBind();
            }
            DropRankType.Items.Insert(0, "--Select--");
        }
        public void BindStudents()
        {
            sqlstmt = "";
            sqlstmt = "Select * from activity_master";
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                DropActivity.DataSource = ds.Tables[0];
                DropActivity.DataTextField = "activity_name";
                DropActivity.DataValueField = "activity_id";
                DropActivity.DataBind();
            }
            else
            {
                DropActivity.DataSource = System.DBNull.Value.ToString();
                DropActivity.DataBind();
            }
            DropActivity.Items.Insert(0, "--Select--");
        }
        public void GetData()
        {
            var unique_id = ViewState["Id"].ToString();
            if (unique_id != null)
            {
                sqlstmt = "";
                sqlstmt = "Select * from rank_requirement where rank_history_id =" + unique_id.ToString();
                DataSet ds = cls.Select(sqlstmt);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    DropRankType.SelectedValue = ds.Tables[0].Rows[0]["rank_type_id"].ToString();
                    DropActivity.SelectedValue = ds.Tables[0].Rows[0]["rank_activity_id"].ToString();
                }
            }

        }

        public void BindData()
        {
            sqlstmt = "";
            sqlstmt = "SELECT * FROM rank_requirement INNER JOIN activity_master ON rank_requirement.rank_activity_id = activity_master.activity_id INNER JOIN rank_type_master ON rank_requirement.rank_type_id = rank_type_master.rank_type_id";
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                Lst_Requirements.DataSource = ds.Tables[0];
                Lst_Requirements.DataBind();
            }
            else
            {
                Lst_Requirements.DataSource = null;
            }
        }

        public void CrudOP()
        {
            //var unique_id = ViewState["Id"].ToString();
            if (ViewState["Id"] == null)
            {
                sqlstmt = "";
                sqlstmt = "Insert into rank_requirement (rank_type_id,rank_activity_id) values ('" + DropRankType.SelectedValue + "','" + DropActivity.SelectedValue + "')";
                cls.Insert(sqlstmt);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Activity", "alert('Record Inserted..!')", true);
                Response.Redirect("Rank_Requirements.aspx");
                //ShowMessageBox("Activities.aspx","Record Inserted..!");    
            }
            else
            {
                sqlstmt = "";
                sqlstmt = "Update rank_requirement set rank_type_id = '" + DropRankType.SelectedValue + "', rank_activity_id = '" + DropActivity.SelectedValue + "' where rank_requirement_id=" + ViewState["Id"].ToString();
                cls.Update(sqlstmt);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Activity", "alert('Record Updated..!')", true);
                Response.Redirect("Rank_Requirements.aspx");
                //ShowMessageBox("Activities.aspx", "Record Updated..!");
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            CrudOP();
        }

        protected void lnkEdit_Click(object sender, EventArgs e)
        {
            LinkButton lnk = (LinkButton)sender;
            ViewState["Id"] = lnk.CommandArgument.ToString();
            GetData();
        }

        protected void lnkDelete_Click(object sender, EventArgs e)
        {
            LinkButton lnk = (LinkButton)sender;
            ViewState["Id"] = lnk.CommandArgument.ToString();
            sqlstmt = "";
            sqlstmt = "Delete from rank_requirement where rank_requirement_id=" + ViewState["Id"].ToString();
            cls.Delete(sqlstmt);
            ShowMessageBox();
        }
        private void ShowMessageBox()
        {
            string sJavaScript = "<script language=javascript>\n";
            sJavaScript += "agree = confirm('Record Deleted...'); \n";
            sJavaScript += "if(agree)\n";
            sJavaScript += "window.location = \"Rank_Requirements.aspx\";\n";
            sJavaScript += "</script>";
            Response.Write(sJavaScript);
        }
    }
}
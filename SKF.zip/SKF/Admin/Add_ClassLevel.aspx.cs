﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace SKF.Admin
{
    public partial class Add_ClassLevel : System.Web.UI.Page
    {
        Connect cls = new Connect();
        string sqlstmt = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindSchool();
                var unique_id = Request.QueryString["id"];
                if (unique_id != null)
                {
                    GetData();
                }
            }
        }

        public void BindSchool()
        {
            sqlstmt = "";
            sqlstmt = "Select * from class_level_master";
            DataSet ds = cls.Select(sqlstmt);
            //if (ds.Tables[0].Rows.Count > 0)
            //{
            //    DropSchooName.DataSource = ds.Tables[0];
            //    DropSchooName.DataTextField = "school_name";
            //    DropSchooName.DataValueField = "school_id";
            //    DropSchooName.DataBind();
            //}
            //else
            //{
            //    DropSchooName.DataSource = System.DBNull.Value.ToString();
            //    DropSchooName.DataBind();
            //}
            //DropSchooName.Items.Insert(0, "--Select--");
        }

        public void GetData()
        {
            var unique_id = Request.QueryString["id"];
            sqlstmt = "";
            sqlstmt = "Select class_level,class_level_desc ,DATE_FORMAT(class_start_date,'%Y-%m-%d') class_start_date,DATE_FORMAT(class_end_date,'%Y-%m-%d') class_end_date ,class_start_time,class_end_time from class_level_master where class_level_id = " + unique_id.ToString();
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
               
                txtAddclasslevelclassLevel.Text = ds.Tables[0].Rows[0]["class_level"].ToString();
                txtAddclasslevelDesc.Text = ds.Tables[0].Rows[0]["class_level_desc"].ToString();
                //txtAddclasslevelDesc.Text = ds.Tables[0].Rows[0]["class_level_desc"].
                txtAddclasslevelstartDate.Text = ds.Tables[0].Rows[0]["class_start_date"].ToString();
                txtAddclasslevelendDate.Text = ds.Tables[0].Rows[0]["class_end_date"].ToString();
                txtAddclasslevelstartTime.Text = ds.Tables[0].Rows[0]["class_start_time"].ToString();
                txtAddclasslevelendTime.Text = ds.Tables[0].Rows[0]["class_end_time"].ToString();
                
            }
        }

        public void CrudOP()
        {
            var unique_id = Request.QueryString["id"];
            if (unique_id == null)
            {
                sqlstmt = "";
                sqlstmt = "Insert into class_level_master (class_level,class_level_desc,class_start_date,class_end_date,class_start_time,class_end_time) values ('"+ txtAddclasslevelclassLevel.Text.Trim() +"', '"+ txtAddclasslevelDesc.Text.Trim() +"', '"+ txtAddclasslevelstartDate.Text.Trim() +"', '"+ txtAddclasslevelendDate.Text.Trim() +"', '"+ txtAddclasslevelstartTime.Text.Trim() +"', '"+ txtAddclasslevelendTime.Text.Trim() +"') ";
                cls.Insert(sqlstmt);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Activity", "alert('Record Inserted..!')", true);
                Response.Redirect("Class_Level.aspx");
                //ShowMessageBox("Activities.aspx","Record Inserted..!");    
            }
            else
            {
                sqlstmt = "";
                sqlstmt = "Update class_level_master set class_level = '" + txtAddclasslevelclassLevel.Text.Trim() + "', class_level_desc = '" + txtAddclasslevelDesc.Text.Trim() + "',class_start_date = '" + txtAddclasslevelstartDate.Text.Trim() + "',class_end_date = '" + txtAddclasslevelendDate.Text.Trim() + "',class_start_time = '" + txtAddclasslevelstartTime.Text.Trim() + "',class_end_time = '" + txtAddclasslevelendTime.Text.Trim() + "' where class_level_id =" + unique_id.ToString();
                cls.Update(sqlstmt);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Activity", "alert('Record Updated..!')", true);
                Response.Redirect("Class_Level.aspx");
                //ShowMessageBox("Activities.aspx", "Record Updated..!");
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            CrudOP();
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace SKF.Admin
{
    public partial class Rank_Progress : System.Web.UI.Page
    {
        Connect cls = new Connect();
        string sqlstmt = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindActivity();
                BindStudents();
                BindData();
            }
        }
        public void BindActivity()
        {
            sqlstmt = "";
            sqlstmt = "Select * from activity_master";
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                DropActivityName.DataSource = ds.Tables[0];
                DropActivityName.DataTextField = "activity_name";
                DropActivityName.DataValueField = "activity_id";
                DropActivityName.DataBind();
            }
            else
            {
                DropActivityName.DataSource = System.DBNull.Value.ToString();
                DropActivityName.DataBind();
            }
            DropActivityName.Items.Insert(0, "--Select--");
        }
        public void BindStudents()
        {
            sqlstmt = "";
            sqlstmt = "Select * from student_master";
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                DropStuName.DataSource = ds.Tables[0];
                DropStuName.DataTextField = "stu_email";
                DropStuName.DataValueField = "stu_id";
                DropStuName.DataBind();
            }
            else
            {
                DropStuName.DataSource = System.DBNull.Value.ToString();
                DropStuName.DataBind();
            }
            DropStuName.Items.Insert(0, "--Select--");
        }
        public void GetData()
        {
            var unique_id = ViewState["Id"].ToString();
            if (unique_id != null)
            {
                sqlstmt = "";
                sqlstmt = "SELECT progress_id,progress_activity_id,progress_stu_id,student_master.stu_email, activity_master.activity_name, DATE_FORMAT(progress_date,'%Y-%m-%d') AS progress_date FROM progress_master INNER JOIN activity_master ON progress_master.progress_activity_id = activity_master.activity_id INNER JOIN student_master ON progress_master.progress_stu_id = student_master.stu_id where progress_id = " + unique_id.ToString();
                DataSet ds = cls.Select(sqlstmt);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    DropActivityName.SelectedValue = ds.Tables[0].Rows[0]["progress_activity_id"].ToString();
                    DropStuName.SelectedValue = ds.Tables[0].Rows[0]["progress_stu_id"].ToString();
                    txtCompletedDate.Value = ds.Tables[0].Rows[0]["progress_date"].ToString();
                }
            }

        }

        public void BindData()
        {
            sqlstmt = "";
            sqlstmt = "SELECT progress_id,student_master.stu_fname,student_master.stu_lname,student_master.stu_email, activity_master.activity_name, DATE_FORMAT(progress_date,'%Y-%m-%d') AS progress_date FROM progress_master INNER JOIN activity_master ON progress_master.progress_activity_id = activity_master.activity_id INNER JOIN student_master ON progress_master.progress_stu_id = student_master.stu_id";
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                Lst_Designation.DataSource = ds.Tables[0];
                Lst_Designation.DataBind();
            }
            else
            {
                Lst_Designation.DataSource = null;
            }
        }

        public void CrudOP()
        {
            //var unique_id = ViewState["Id"].ToString();
            if (ViewState["Id"] == null)
            {
                sqlstmt = "";
                sqlstmt = "Insert into progress_master (progress_stu_id,progress_rank_id,progress_activity_id,progress_date,progress_status) values ('" + DropStuName.SelectedValue + "','" + txtrank_Name.Text + "','" + DropActivityName.SelectedValue + "','" + txtCompletedDate.Value.Trim() + "','Clear')";
                cls.Insert(sqlstmt);
                Rank_History();
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Activity", "alert('Record Inserted..!')", true);
                Response.Redirect("Rank_Progress.aspx");
                //ShowMessageBox("Activities.aspx","Record Inserted..!");    
            }
            else
            {
                sqlstmt = "";
                sqlstmt = "Update progress_master set progress_stu_id = '" + DropStuName.SelectedValue + "', progress_activity_id = '" + DropActivityName.SelectedValue + "',progress_date = '" + txtCompletedDate.Value + "' where progress_id=" + ViewState["Id"].ToString();
                cls.Update(sqlstmt);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Activity", "alert('Record Updated..!')", true);
                Response.Redirect("Rank_Progress.aspx");
                //ShowMessageBox("Activities.aspx", "Record Updated..!");
            }
        }

        public void Rank_History()
        {
            int cnt_req = 0;
            int cnt_progress = 0;
            string req_type_id ="";
            sqlstmt = "";
            sqlstmt = "Select * from rank_requirement where rank_type_id =" + txtrank_Name.Text;
            DataSet ds_req = cls.Select(sqlstmt);
            cnt_req = ds_req.Tables[0].Rows.Count;
            if(ds_req.Tables[0].Rows.Count >0)
            {
                req_type_id = ds_req.Tables[0].Rows[0]["rank_type_id"].ToString();
            }

            sqlstmt = "";
            sqlstmt = "Select * from progress_master where progress_rank_id =" + txtrank_Name.Text + " and progress_stu_id = "+DropStuName.SelectedValue;
            DataSet ds_progress = cls.Select(sqlstmt);
            cnt_progress = ds_progress.Tables[0].Rows.Count;

            if(cnt_req == cnt_progress)
            {
                string cdate = System.DateTime.Now.ToString("yyyy-MM-dd");
                sqlstmt = "";
                sqlstmt = "Insert into rank_history (rank_type_id,rank_stu_id,rank_date) values ('"+ req_type_id.ToString() +"','"+ DropStuName.SelectedValue +"','"+ cdate.ToString() +"')";
                cls.Insert(sqlstmt);
            }

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            CrudOP();
        }

        protected void lnkEdit_Click(object sender, EventArgs e)
        {
            LinkButton lnk = (LinkButton)sender;
            ViewState["Id"] = lnk.CommandArgument.ToString();
            GetData();
        }

        protected void lnkDelete_Click(object sender, EventArgs e)
        {
            LinkButton lnk = (LinkButton)sender;
            ViewState["Id"] = lnk.CommandArgument.ToString();
            sqlstmt = "";
            sqlstmt = "Delete from progress_master where progress_id=" + ViewState["Id"].ToString();
            cls.Delete(sqlstmt);
            ShowMessageBox();
        }
        private void ShowMessageBox()
        {
            string sJavaScript = "<script language=javascript>\n";
            sJavaScript += "agree = confirm('Record Deleted...'); \n";
            sJavaScript += "if(agree)\n";
            sJavaScript += "window.location = \"Rank_Progress.aspx\";\n";
            sJavaScript += "</script>";
            Response.Write(sJavaScript);
        }

        protected void DropActivityName_SelectedIndexChanged(object sender, EventArgs e)
        {
            sqlstmt = "";
            sqlstmt = "SELECT rank_requirement.rank_type_id FROM rank_requirement WHERE rank_requirement.rank_activity_id = " + DropActivityName.SelectedValue;
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                txtrank_Name.Text = ds.Tables[0].Rows[0]["rank_type_id"].ToString();
            }
        }
    }
}
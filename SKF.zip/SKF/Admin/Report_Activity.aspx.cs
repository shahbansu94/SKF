﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace SKF.Admin
{
    public partial class Report_Activity : System.Web.UI.Page
    {
        Connect cls = new Connect();
        string sqlstmt = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindClassLevel();
                BindActivity();               
            }
        }

      
        public void BindData()
        {
            sqlstmt = "";
            sqlstmt = "SELECT enroll_master.enroll_student_id, student_master.stu_fname, student_master.stu_lname, class_level_master.class_level, activity_master.activity_name FROM enroll_master INNER JOIN student_master ON enroll_master.enroll_student_id = student_master.stu_id INNER JOIN class_master ON enroll_master.enroll_class_id = class_master.class_id INNER JOIN class_level_master ON class_master.class_level_id = class_level_master.class_level_id INNER JOIN activity_master ON class_level_master.class_level_id = activity_master.activity_class_level_id WHERE class_level_master.class_level_id = " + DropClassLevel.SelectedValue;
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                Lst_Activity_Report.Visible = true;
                Lst_Activity_Report.DataSource = ds.Tables[0];
                Lst_Activity_Report.DataBind();
            }
            else
            {
                Lst_Activity_Report.DataSource = null;
                Lst_Activity_Report.Visible = false;
            }
        }

        public void BindData1()
        {
            sqlstmt = "";
            sqlstmt = "SELECT enroll_master.enroll_student_id, student_master.stu_fname, student_master.stu_lname, class_level_master.class_level, activity_master.activity_name FROM enroll_master INNER JOIN student_master ON enroll_master.enroll_student_id = student_master.stu_id INNER JOIN class_master ON enroll_master.enroll_class_id = class_master.class_id INNER JOIN class_level_master ON class_master.class_level_id = class_level_master.class_level_id INNER JOIN activity_master ON class_level_master.class_level_id = activity_master.activity_class_level_id WHERE activity_master.activity_id = " + DropActivity.SelectedValue;
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                Lst_Activity_Report.Visible = true;
                Lst_Activity_Report.DataSource = ds.Tables[0];
                Lst_Activity_Report.DataBind();
            }
            else
            {
                Lst_Activity_Report.DataSource = null;
                Lst_Activity_Report.Visible = false;
            }
        }

        public void BindData2()
        {
            sqlstmt = "";
            sqlstmt = "SELECT enroll_master.enroll_student_id, student_master.stu_fname, student_master.stu_lname, class_level_master.class_level, activity_master.activity_name FROM enroll_master INNER JOIN student_master ON enroll_master.enroll_student_id = student_master.stu_id INNER JOIN class_master ON enroll_master.enroll_class_id = class_master.class_id INNER JOIN class_level_master ON class_master.class_level_id = class_level_master.class_level_id INNER JOIN activity_master ON class_level_master.class_level_id = activity_master.activity_class_level_id WHERE activity_master.activity_id = " + DropActivity.SelectedValue + " AND class_level_master.class_level_id = " + DropClassLevel.SelectedValue;
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                Lst_Activity_Report.Visible = true;
                Lst_Activity_Report.DataSource = ds.Tables[0];
                Lst_Activity_Report.DataBind();
            }
            else
            {
                Lst_Activity_Report.DataSource = null;
                Lst_Activity_Report.Visible = false;
            }
        }

        public void BindClassLevel()
        {
            sqlstmt = "";
            sqlstmt = "Select * from class_level_master";
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                DropClassLevel.DataSource = ds.Tables[0];
                DropClassLevel.DataTextField = "class_level";
                DropClassLevel.DataValueField = "class_level_id";
                DropClassLevel.DataBind();
            }
            else
            {
                DropClassLevel.DataSource = System.DBNull.Value.ToString();
                DropClassLevel.DataBind();
            }
            DropClassLevel.Items.Insert(0, "--Select--");
        }

        public void BindActivity()
        {
            sqlstmt = "";
            sqlstmt = "Select * from activity_master";
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                DropActivity.DataSource = ds.Tables[0];
                DropActivity.DataTextField = "activity_name";
                DropActivity.DataValueField = "activity_id";
                DropActivity.DataBind();
            }
            else
            {
                DropActivity.DataSource = System.DBNull.Value.ToString();
                DropActivity.DataBind();
            }
            DropActivity.Items.Insert(0, "--Select--");
        }   

                
        protected void DropClassLevel_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DropClassLevel.Items.FindByValue("1").Selected == true)
            {
                BindData();
            }
            else
            {
                BindData2();
            }
        }

        protected void DropActivity_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DropActivity.Items.FindByValue("1").Selected == true)
            {
                BindData1();
            }
            else
            {
                BindData2();
            }            
        }
    }
}
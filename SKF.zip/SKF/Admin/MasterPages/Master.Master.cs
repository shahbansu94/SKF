﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SKF.Admin.MasterPages
{
    public partial class Master : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                HttpCookie reqCookies = Request.Cookies["userInfo"];
                if (reqCookies != null)
                {
                    lblHeaderUser.Text = reqCookies["UserName"].ToString();
                    lblUsr.Text = reqCookies["UserName"].ToString();
                    SetMenu();
                    //Response.Redirect("Index.aspx");
                }
                else
                {
                    lblHeaderUser.Text = "Admin";
                    lblUsr.Text = "Admin";
                    //Response.Redirect("Login.aspx");
                }
            }
        }
        public void Logout()
        {
            HttpCookie _userInfoCookies = new HttpCookie("userInfo");
            //Adding Expire Time of cookies before existing cookies time
            _userInfoCookies.Expires = DateTime.Now.AddDays(-1);
            //Adding cookies to current web response
            Response.Cookies.Add(_userInfoCookies);
            Response.Redirect("Login.aspx");
        }
        public void SetMenu()
        {
            HttpCookie reqCookies = Request.Cookies["userInfo"];
            if (reqCookies != null)
            {
                string userName = reqCookies["UserName"].ToString();
                string userType = reqCookies["UserType"].ToString();
                //imgProfile.Src = reqCookies["UserProfilePic"].ToString();

                if (userType == "Master_Admin")
                {
                    Master_Admin.Visible = true;
                    School_Student.Visible = false;
                }
                else if (userType == "School_Student")
                {
                    Master_Admin.Visible = false;
                    School_Student.Visible = true;
                }
                else
                {
                    Logout();
                }
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SKF.Admin
{
    public partial class Report_Student : System.Web.UI.Page
    {
        Connect cls = new Connect();
        string sqlstmt = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
              
            }

        }

        public void BindData()
        {
            sqlstmt = "";
            if (DropStudentType.SelectedValue == "Registered")
            {
                sqlstmt = "SELECT * FROM student_master";
                DataSet ds = cls.Select(sqlstmt);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    Lst_StudentRpt.Visible = true;
                    Lst_StudentRpt.DataSource = ds.Tables[0];
                    Lst_StudentRpt.DataBind();
                }
                else
                {
                    Lst_StudentRpt.DataSource = null;
                    Lst_StudentRpt.Visible = false;
                }
            }
            else 
            {
                sqlstmt = "SELECT student_master.stu_fname,student_master.stu_lname,student_master.stu_email,student_master.stu_phone,student_master.stu_is_active FROM enroll_master INNER JOIN student_master ON enroll_master.enroll_student_id = student_master.stu_id";
                DataSet ds = cls.Select(sqlstmt);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    Lst_StudentRpt.Visible = true;
                    Lst_StudentRpt.DataSource = ds.Tables[0];
                    Lst_StudentRpt.DataBind();
                }
                else
                {
                    Lst_StudentRpt.DataSource = null;
                    Lst_StudentRpt.Visible = false;
                }
            }
        }

        public void BindData1()
        {
            string startdate = TxtStartDate.Value.Trim();
            string enddate = txtEndDate.Value.Trim();
            sqlstmt = "";
            if (DropStudentType.SelectedValue == "Registered")
            {
                sqlstmt = "SELECT student_master.stu_fname, student_master.stu_lname, student_master.stu_email, student_master.stu_phone, student_master.stu_is_active FROM student_master WHERE stu_join_date BETWEEN '"+ startdate +"' AND '"+ enddate +"'";
                DataSet ds = cls.Select(sqlstmt);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    Lst_StudentRpt.Visible = true;
                    Lst_StudentRpt.DataSource = ds.Tables[0];
                    Lst_StudentRpt.DataBind();
                }
                else
                {
                    Lst_StudentRpt.DataSource = null;
                    Lst_StudentRpt.Visible = false;
                }
            }
            else
            {
                sqlstmt = "SELECT student_master.stu_fname,student_master.stu_lname,student_master.stu_email,student_master.stu_phone,student_master.stu_is_active FROM enroll_master INNER JOIN student_master ON enroll_master.enroll_student_id = student_master.stu_id WHERE enroll_date BETWEEN '" + startdate + "' AND '" + enddate + "'";
                DataSet ds = cls.Select(sqlstmt);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    Lst_StudentRpt.Visible = true;
                    Lst_StudentRpt.DataSource = ds.Tables[0];
                    Lst_StudentRpt.DataBind();
                }
                else
                {
                    Lst_StudentRpt.DataSource = null;
                    Lst_StudentRpt.Visible = false;
                }
            }
        }

        protected void DropStudentType_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindData();
        }

       
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            BindData1();
        }
    }
}